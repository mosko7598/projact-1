def get_portfolio_value():
    return {
        "BTC": 70000,
        "ETH": 3500,
        "USDT": 10000,
        "total_usd": 83500
    }
